﻿namespace SALARIOPROJETO
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.RadioButton rdFeminino;
            this.NomeFunc = new System.Windows.Forms.Label();
            this.salBruto = new System.Windows.Forms.Label();
            this.numFilhos = new System.Windows.Forms.Label();
            this.AliquotaINSS = new System.Windows.Forms.Label();
            this.AliquotaIRPF = new System.Windows.Forms.Label();
            this.salFamilia = new System.Windows.Forms.Label();
            this.TxtNomeFunc = new System.Windows.Forms.TextBox();
            this.MskbxSalBruto = new System.Windows.Forms.TextBox();
            this.txtAliqINSS = new System.Windows.Forms.TextBox();
            this.txtAliqIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.CbxNumFilhos = new System.Windows.Forms.ComboBox();
            this.descontoINSS = new System.Windows.Forms.Label();
            this.descontoIRPF = new System.Windows.Forms.Label();
            this.salLiquido = new System.Windows.Forms.Label();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdMasculino = new System.Windows.Forms.RadioButton();
            this.btnVerificarDados = new System.Windows.Forms.Button();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.lblDados = new System.Windows.Forms.Label();
            rdFeminino = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // NomeFunc
            // 
            this.NomeFunc.AutoSize = true;
            this.NomeFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NomeFunc.Location = new System.Drawing.Point(21, 9);
            this.NomeFunc.Name = "NomeFunc";
            this.NomeFunc.Size = new System.Drawing.Size(138, 20);
            this.NomeFunc.TabIndex = 0;
            this.NomeFunc.Text = "Nome Funcionario";
            // 
            // salBruto
            // 
            this.salBruto.AutoSize = true;
            this.salBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salBruto.Location = new System.Drawing.Point(21, 56);
            this.salBruto.Name = "salBruto";
            this.salBruto.Size = new System.Drawing.Size(101, 20);
            this.salBruto.TabIndex = 1;
            this.salBruto.Text = "Salario Bruto";
            // 
            // numFilhos
            // 
            this.numFilhos.AutoSize = true;
            this.numFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numFilhos.Location = new System.Drawing.Point(23, 102);
            this.numFilhos.Name = "numFilhos";
            this.numFilhos.Size = new System.Drawing.Size(111, 20);
            this.numFilhos.TabIndex = 2;
            this.numFilhos.Text = "Numero Filhos";
            // 
            // AliquotaINSS
            // 
            this.AliquotaINSS.AutoSize = true;
            this.AliquotaINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AliquotaINSS.Location = new System.Drawing.Point(26, 251);
            this.AliquotaINSS.Name = "AliquotaINSS";
            this.AliquotaINSS.Size = new System.Drawing.Size(109, 20);
            this.AliquotaINSS.TabIndex = 3;
            this.AliquotaINSS.Text = "Aliquota INSS";
            // 
            // AliquotaIRPF
            // 
            this.AliquotaIRPF.AutoSize = true;
            this.AliquotaIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AliquotaIRPF.Location = new System.Drawing.Point(27, 304);
            this.AliquotaIRPF.Name = "AliquotaIRPF";
            this.AliquotaIRPF.Size = new System.Drawing.Size(108, 20);
            this.AliquotaIRPF.TabIndex = 4;
            this.AliquotaIRPF.Text = "Aliquota IRPF";
            // 
            // salFamilia
            // 
            this.salFamilia.AutoSize = true;
            this.salFamilia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salFamilia.Location = new System.Drawing.Point(23, 353);
            this.salFamilia.Name = "salFamilia";
            this.salFamilia.Size = new System.Drawing.Size(112, 20);
            this.salFamilia.TabIndex = 5;
            this.salFamilia.Text = "Salario Familia";
            // 
            // TxtNomeFunc
            // 
            this.TxtNomeFunc.Location = new System.Drawing.Point(165, 9);
            this.TxtNomeFunc.Name = "TxtNomeFunc";
            this.TxtNomeFunc.Size = new System.Drawing.Size(192, 20);
            this.TxtNomeFunc.TabIndex = 6;
            // 
            // MskbxSalBruto
            // 
            this.MskbxSalBruto.Location = new System.Drawing.Point(165, 56);
            this.MskbxSalBruto.Name = "MskbxSalBruto";
            this.MskbxSalBruto.Size = new System.Drawing.Size(192, 20);
            this.MskbxSalBruto.TabIndex = 7;
            // 
            // txtAliqINSS
            // 
            this.txtAliqINSS.Location = new System.Drawing.Point(165, 251);
            this.txtAliqINSS.Name = "txtAliqINSS";
            this.txtAliqINSS.Size = new System.Drawing.Size(192, 20);
            this.txtAliqINSS.TabIndex = 8;
            // 
            // txtAliqIRPF
            // 
            this.txtAliqIRPF.Location = new System.Drawing.Point(165, 304);
            this.txtAliqIRPF.Name = "txtAliqIRPF";
            this.txtAliqIRPF.Size = new System.Drawing.Size(192, 20);
            this.txtAliqIRPF.TabIndex = 9;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Location = new System.Drawing.Point(165, 355);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(192, 20);
            this.txtSalFamilia.TabIndex = 10;
            // 
            // CbxNumFilhos
            // 
            this.CbxNumFilhos.FormattingEnabled = true;
            this.CbxNumFilhos.Location = new System.Drawing.Point(165, 102);
            this.CbxNumFilhos.Name = "CbxNumFilhos";
            this.CbxNumFilhos.Size = new System.Drawing.Size(192, 21);
            this.CbxNumFilhos.TabIndex = 11;
            // 
            // descontoINSS
            // 
            this.descontoINSS.AutoSize = true;
            this.descontoINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.descontoINSS.Location = new System.Drawing.Point(381, 304);
            this.descontoINSS.Name = "descontoINSS";
            this.descontoINSS.Size = new System.Drawing.Size(120, 20);
            this.descontoINSS.TabIndex = 12;
            this.descontoINSS.Text = "Desconto INSS";
            // 
            // descontoIRPF
            // 
            this.descontoIRPF.AutoSize = true;
            this.descontoIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.descontoIRPF.Location = new System.Drawing.Point(381, 353);
            this.descontoIRPF.Name = "descontoIRPF";
            this.descontoIRPF.Size = new System.Drawing.Size(119, 20);
            this.descontoIRPF.TabIndex = 13;
            this.descontoIRPF.Text = "Desconto IRPF";
            this.descontoIRPF.Click += new System.EventHandler(this.DescontoIRPF_Click);
            // 
            // salLiquido
            // 
            this.salLiquido.AutoSize = true;
            this.salLiquido.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salLiquido.Location = new System.Drawing.Point(381, 253);
            this.salLiquido.Name = "salLiquido";
            this.salLiquido.Size = new System.Drawing.Size(113, 20);
            this.salLiquido.TabIndex = 14;
            this.salLiquido.Text = "Salario Liquido";
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Location = new System.Drawing.Point(500, 251);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.Size = new System.Drawing.Size(171, 20);
            this.txtSalLiquido.TabIndex = 15;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Location = new System.Drawing.Point(500, 304);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(171, 20);
            this.txtDescINSS.TabIndex = 16;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Location = new System.Drawing.Point(500, 353);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(171, 20);
            this.txtDescIRPF.TabIndex = 17;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdMasculino);
            this.groupBox1.Controls.Add(rdFeminino);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(422, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sexo";
            // 
            // rdMasculino
            // 
            this.rdMasculino.AutoSize = true;
            this.rdMasculino.Location = new System.Drawing.Point(21, 70);
            this.rdMasculino.Name = "rdMasculino";
            this.rdMasculino.Size = new System.Drawing.Size(98, 24);
            this.rdMasculino.TabIndex = 1;
            this.rdMasculino.TabStop = true;
            this.rdMasculino.Text = "Masculino";
            this.rdMasculino.UseVisualStyleBackColor = true;
            // 
            // rdFeminino
            // 
            rdFeminino.AutoSize = true;
            rdFeminino.Location = new System.Drawing.Point(21, 25);
            rdFeminino.Name = "rdFeminino";
            rdFeminino.Size = new System.Drawing.Size(92, 24);
            rdFeminino.TabIndex = 0;
            rdFeminino.TabStop = true;
            rdFeminino.Text = "Feminino";
            rdFeminino.UseVisualStyleBackColor = true;
            // 
            // btnVerificarDados
            // 
            this.btnVerificarDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificarDados.Location = new System.Drawing.Point(165, 143);
            this.btnVerificarDados.Name = "btnVerificarDados";
            this.btnVerificarDados.Size = new System.Drawing.Size(192, 31);
            this.btnVerificarDados.TabIndex = 19;
            this.btnVerificarDados.Text = "Verificar Dados";
            this.btnVerificarDados.UseVisualStyleBackColor = true;
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ckbxCasado.Location = new System.Drawing.Point(479, 147);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(83, 24);
            this.ckbxCasado.TabIndex = 20;
            this.ckbxCasado.Text = "Casado";
            this.ckbxCasado.UseVisualStyleBackColor = true;
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDados.Location = new System.Drawing.Point(23, 199);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(77, 20);
            this.lblDados.TabIndex = 21;
            this.lblDados.Text = "LblDados";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.ckbxCasado);
            this.Controls.Add(this.btnVerificarDados);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.salLiquido);
            this.Controls.Add(this.descontoIRPF);
            this.Controls.Add(this.descontoINSS);
            this.Controls.Add(this.CbxNumFilhos);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAliqIRPF);
            this.Controls.Add(this.txtAliqINSS);
            this.Controls.Add(this.MskbxSalBruto);
            this.Controls.Add(this.TxtNomeFunc);
            this.Controls.Add(this.salFamilia);
            this.Controls.Add(this.AliquotaIRPF);
            this.Controls.Add(this.AliquotaINSS);
            this.Controls.Add(this.numFilhos);
            this.Controls.Add(this.salBruto);
            this.Controls.Add(this.NomeFunc);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label NomeFunc;
        private System.Windows.Forms.Label salBruto;
        private System.Windows.Forms.Label numFilhos;
        private System.Windows.Forms.Label AliquotaINSS;
        private System.Windows.Forms.Label AliquotaIRPF;
        private System.Windows.Forms.Label salFamilia;
        private System.Windows.Forms.TextBox TxtNomeFunc;
        private System.Windows.Forms.TextBox MskbxSalBruto;
        private System.Windows.Forms.TextBox txtAliqINSS;
        private System.Windows.Forms.TextBox txtAliqIRPF;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.ComboBox CbxNumFilhos;
        private System.Windows.Forms.Label descontoINSS;
        private System.Windows.Forms.Label descontoIRPF;
        private System.Windows.Forms.Label salLiquido;
        private System.Windows.Forms.TextBox txtSalLiquido;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdMasculino;
        private System.Windows.Forms.Button btnVerificarDados;
        private System.Windows.Forms.CheckBox ckbxCasado;
        private System.Windows.Forms.Label lblDados;
    }
}

