﻿namespace Psalario
{
    partial class Atividade5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.mskbxSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.cbxNumFilhos = new System.Windows.Forms.ComboBox();
            this.btnVerifica = new System.Windows.Forms.Button();
            this.grpbxSexo = new System.Windows.Forms.GroupBox();
            this.rbtnMas = new System.Windows.Forms.RadioButton();
            this.rbtnFem = new System.Windows.Forms.RadioButton();
            this.pnlCasado = new System.Windows.Forms.Panel();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.lblnss = new System.Windows.Forms.Label();
            this.lblIrpf = new System.Windows.Forms.Label();
            this.lblSalFam = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblDescInss = new System.Windows.Forms.Label();
            this.lblDescIrpf = new System.Windows.Forms.Label();
            this.txtDescInss = new System.Windows.Forms.TextBox();
            this.txtDescIrpf = new System.Windows.Forms.TextBox();
            this.txtInss = new System.Windows.Forms.TextBox();
            this.txtIrpf = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.lblDados = new System.Windows.Forms.Label();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.grpbxSexo.SuspendLayout();
            this.pnlCasado.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblNome.Location = new System.Drawing.Point(61, 69);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(119, 17);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome funcionário";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblSalBruto.Location = new System.Drawing.Point(61, 127);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(90, 17);
            this.lblSalBruto.TabIndex = 1;
            this.lblSalBruto.Text = "Salario Bruto";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblFilhos.Location = new System.Drawing.Point(61, 185);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(115, 17);
            this.lblFilhos.TabIndex = 2;
            this.lblFilhos.Text = "Número de filhos";
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtNome.Location = new System.Drawing.Point(195, 66);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(114, 23);
            this.txtNome.TabIndex = 1;
            this.txtNome.Validated += new System.EventHandler(this.txtNome_Validated);
            // 
            // mskbxSalBruto
            // 
            this.mskbxSalBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.mskbxSalBruto.Location = new System.Drawing.Point(195, 124);
            this.mskbxSalBruto.Mask = "99999.00";
            this.mskbxSalBruto.Name = "mskbxSalBruto";
            this.mskbxSalBruto.Size = new System.Drawing.Size(114, 23);
            this.mskbxSalBruto.TabIndex = 2;
            this.mskbxSalBruto.Validated += new System.EventHandler(this.mskbxSalBruto_Validated);
            // 
            // cbxNumFilhos
            // 
            this.cbxNumFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.cbxNumFilhos.FormattingEnabled = true;
            this.cbxNumFilhos.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.cbxNumFilhos.Location = new System.Drawing.Point(195, 182);
            this.cbxNumFilhos.Name = "cbxNumFilhos";
            this.cbxNumFilhos.Size = new System.Drawing.Size(114, 24);
            this.cbxNumFilhos.TabIndex = 3;
            this.cbxNumFilhos.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // btnVerifica
            // 
            this.btnVerifica.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btnVerifica.Location = new System.Drawing.Point(132, 232);
            this.btnVerifica.Name = "btnVerifica";
            this.btnVerifica.Size = new System.Drawing.Size(227, 47);
            this.btnVerifica.TabIndex = 4;
            this.btnVerifica.Text = "Verificar Desconto";
            this.btnVerifica.UseVisualStyleBackColor = true;
            this.btnVerifica.Click += new System.EventHandler(this.btnVerifica_Click);
            // 
            // grpbxSexo
            // 
            this.grpbxSexo.Controls.Add(this.rbtnMas);
            this.grpbxSexo.Controls.Add(this.rbtnFem);
            this.grpbxSexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.grpbxSexo.Location = new System.Drawing.Point(472, 39);
            this.grpbxSexo.Name = "grpbxSexo";
            this.grpbxSexo.Size = new System.Drawing.Size(232, 158);
            this.grpbxSexo.TabIndex = 7;
            this.grpbxSexo.TabStop = false;
            this.grpbxSexo.Text = "Sexo";
            // 
            // rbtnMas
            // 
            this.rbtnMas.AutoSize = true;
            this.rbtnMas.Location = new System.Drawing.Point(71, 91);
            this.rbtnMas.Name = "rbtnMas";
            this.rbtnMas.Size = new System.Drawing.Size(89, 21);
            this.rbtnMas.TabIndex = 1;
            this.rbtnMas.Text = "Masculino";
            this.rbtnMas.UseVisualStyleBackColor = true;
            // 
            // rbtnFem
            // 
            this.rbtnFem.AutoSize = true;
            this.rbtnFem.Checked = true;
            this.rbtnFem.Location = new System.Drawing.Point(71, 49);
            this.rbtnFem.Name = "rbtnFem";
            this.rbtnFem.Size = new System.Drawing.Size(83, 21);
            this.rbtnFem.TabIndex = 0;
            this.rbtnFem.TabStop = true;
            this.rbtnFem.Text = "Feminino";
            this.rbtnFem.UseVisualStyleBackColor = true;
            this.rbtnFem.CheckedChanged += new System.EventHandler(this.rbtnFem_CheckedChanged);
            // 
            // pnlCasado
            // 
            this.pnlCasado.Controls.Add(this.ckbxCasado);
            this.pnlCasado.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.pnlCasado.Location = new System.Drawing.Point(472, 203);
            this.pnlCasado.Name = "pnlCasado";
            this.pnlCasado.Size = new System.Drawing.Size(231, 107);
            this.pnlCasado.TabIndex = 8;
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.Location = new System.Drawing.Point(76, 46);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(75, 21);
            this.ckbxCasado.TabIndex = 0;
            this.ckbxCasado.Text = "Casado";
            this.ckbxCasado.UseVisualStyleBackColor = true;
            // 
            // lblnss
            // 
            this.lblnss.AutoSize = true;
            this.lblnss.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblnss.Location = new System.Drawing.Point(61, 348);
            this.lblnss.Name = "lblnss";
            this.lblnss.Size = new System.Drawing.Size(94, 17);
            this.lblnss.TabIndex = 9;
            this.lblnss.Text = "Aliquota INSS";
            // 
            // lblIrpf
            // 
            this.lblIrpf.AutoSize = true;
            this.lblIrpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblIrpf.Location = new System.Drawing.Point(61, 404);
            this.lblIrpf.Name = "lblIrpf";
            this.lblIrpf.Size = new System.Drawing.Size(93, 17);
            this.lblIrpf.TabIndex = 10;
            this.lblIrpf.Text = "Aliquota IRPF";
            // 
            // lblSalFam
            // 
            this.lblSalFam.AutoSize = true;
            this.lblSalFam.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblSalFam.Location = new System.Drawing.Point(61, 461);
            this.lblSalFam.Name = "lblSalFam";
            this.lblSalFam.Size = new System.Drawing.Size(100, 17);
            this.lblSalFam.TabIndex = 11;
            this.lblSalFam.Text = "Salário Familia";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label7.Location = new System.Drawing.Point(61, 519);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 17);
            this.label7.TabIndex = 12;
            this.label7.Text = "Salário Liquido";
            // 
            // lblDescInss
            // 
            this.lblDescInss.AutoSize = true;
            this.lblDescInss.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblDescInss.Location = new System.Drawing.Point(441, 348);
            this.lblDescInss.Name = "lblDescInss";
            this.lblDescInss.Size = new System.Drawing.Size(103, 17);
            this.lblDescInss.TabIndex = 13;
            this.lblDescInss.Text = "Desconto INSS";
            this.lblDescInss.Click += new System.EventHandler(this.lblDescInss_Click);
            // 
            // lblDescIrpf
            // 
            this.lblDescIrpf.AutoSize = true;
            this.lblDescIrpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblDescIrpf.Location = new System.Drawing.Point(442, 401);
            this.lblDescIrpf.Name = "lblDescIrpf";
            this.lblDescIrpf.Size = new System.Drawing.Size(102, 17);
            this.lblDescIrpf.TabIndex = 14;
            this.lblDescIrpf.Text = "Desconto IRPF";
            this.lblDescIrpf.Click += new System.EventHandler(this.lblDescIrpf_Click);
            // 
            // txtDescInss
            // 
            this.txtDescInss.Enabled = false;
            this.txtDescInss.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtDescInss.Location = new System.Drawing.Point(550, 345);
            this.txtDescInss.Name = "txtDescInss";
            this.txtDescInss.Size = new System.Drawing.Size(115, 23);
            this.txtDescInss.TabIndex = 15;
            this.txtDescInss.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txtDescIrpf
            // 
            this.txtDescIrpf.Enabled = false;
            this.txtDescIrpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtDescIrpf.Location = new System.Drawing.Point(550, 401);
            this.txtDescIrpf.Name = "txtDescIrpf";
            this.txtDescIrpf.Size = new System.Drawing.Size(115, 23);
            this.txtDescIrpf.TabIndex = 16;
            this.txtDescIrpf.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // txtInss
            // 
            this.txtInss.Enabled = false;
            this.txtInss.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtInss.Location = new System.Drawing.Point(194, 345);
            this.txtInss.Name = "txtInss";
            this.txtInss.Size = new System.Drawing.Size(115, 23);
            this.txtInss.TabIndex = 17;
            this.txtInss.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // txtIrpf
            // 
            this.txtIrpf.Enabled = false;
            this.txtIrpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtIrpf.Location = new System.Drawing.Point(195, 401);
            this.txtIrpf.Name = "txtIrpf";
            this.txtIrpf.Size = new System.Drawing.Size(115, 23);
            this.txtIrpf.TabIndex = 18;
            this.txtIrpf.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Enabled = false;
            this.txtSalFamilia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtSalFamilia.Location = new System.Drawing.Point(195, 458);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(115, 23);
            this.txtSalFamilia.TabIndex = 19;
            this.txtSalFamilia.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Enabled = false;
            this.txtSalLiquido.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtSalLiquido.Location = new System.Drawing.Point(194, 516);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.Size = new System.Drawing.Size(115, 23);
            this.txtSalLiquido.TabIndex = 20;
            this.txtSalLiquido.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblDados.Location = new System.Drawing.Point(61, 297);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(49, 17);
            this.lblDados.TabIndex = 21;
            this.lblDados.Text = "Dados";
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(540, 461);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(163, 34);
            this.btnLimpar.TabIndex = 22;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(540, 510);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(163, 34);
            this.btnSair.TabIndex = 23;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // Atividade5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(780, 566);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtIrpf);
            this.Controls.Add(this.txtInss);
            this.Controls.Add(this.txtDescIrpf);
            this.Controls.Add(this.txtDescInss);
            this.Controls.Add(this.lblDescIrpf);
            this.Controls.Add(this.lblDescInss);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblSalFam);
            this.Controls.Add(this.lblIrpf);
            this.Controls.Add(this.lblnss);
            this.Controls.Add(this.pnlCasado);
            this.Controls.Add(this.grpbxSexo);
            this.Controls.Add(this.btnVerifica);
            this.Controls.Add(this.cbxNumFilhos);
            this.Controls.Add(this.mskbxSalBruto);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblNome);
            this.Name = "Atividade5";
            this.Text = "Verificar Desconto";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpbxSexo.ResumeLayout(false);
            this.grpbxSexo.PerformLayout();
            this.pnlCasado.ResumeLayout(false);
            this.pnlCasado.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.MaskedTextBox mskbxSalBruto;
        private System.Windows.Forms.ComboBox cbxNumFilhos;
        private System.Windows.Forms.Button btnVerifica;
        private System.Windows.Forms.GroupBox grpbxSexo;
        private System.Windows.Forms.RadioButton rbtnMas;
        private System.Windows.Forms.RadioButton rbtnFem;
        private System.Windows.Forms.Panel pnlCasado;
        private System.Windows.Forms.CheckBox ckbxCasado;
        private System.Windows.Forms.Label lblnss;
        private System.Windows.Forms.Label lblIrpf;
        private System.Windows.Forms.Label lblSalFam;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblDescInss;
        private System.Windows.Forms.Label lblDescIrpf;
        private System.Windows.Forms.TextBox txtDescInss;
        private System.Windows.Forms.TextBox txtDescIrpf;
        private System.Windows.Forms.TextBox txtInss;
        private System.Windows.Forms.TextBox txtIrpf;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiquido;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
    }
}

