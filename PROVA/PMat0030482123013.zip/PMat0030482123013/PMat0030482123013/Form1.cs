﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMat0030482123013
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] VetorA = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
            int[] VetorB = new int[10];

            for (int i = 0; i <= 9; i++)
            { 
                    if  (i % 2 == 0)
                        VetorB = [] * 5;
                    else (i % 3 == 0)
                        VetorB = [] + 5;
            }



        listBox1.Items.Add("VetorA");        listBox1.Items.Add("VetorB");

        }
    }
}
