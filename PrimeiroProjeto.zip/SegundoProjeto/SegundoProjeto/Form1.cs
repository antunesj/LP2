﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SegundoProjeto
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
                //(textBox1.TextLength==0)
                //(textBox1.Text==String.Empty)
                MessageBox.Show("Nome Vazio!");
            else
                MessageBox.Show("O nome do aluno é:" + textBox1.Text);



            if (comboBox1.SelectedIndex == -1)
                MessageBox.Show("Cidade não selecionada!");
            else
                MessageBox.Show("A cidade do aluno é:" + comboBox1.SelectedItem);

            MessageBox.Show("A turma é:" + listBox1.SelectedItem);



            if (checkBox1.Checked)
                MessageBox.Show("Aluno veio tranferido");
            else if (checkBox1.CheckState == CheckState.Unchecked)
                MessageBox.Show("Aluno não veio tranferido");
            else
                MessageBox.Show("Indeterminado");



            if (radioButton1.Checked)
                MessageBox.Show("Feminino");
            else
                MessageBox.Show("Masculino");

            string stringona = "";

            for (var i = 0; i < checkedListBox1.CheckedItems.Count; i++)
                stringona = stringona + "\n" + checkedListBox1.CheckedItems[i].ToString();

            MessageBox.Show(stringona);


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.Items.Add("1º semestre da manha");
            listBox1.Items.Add("2º semestre da manha");
            listBox1.Items.Add("1º semestre da noite");
            listBox1.Items.Add("2º semestre da noite");

            listBox1.SelectedIndex = 1;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
